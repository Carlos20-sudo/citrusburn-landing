# Landing Page CitrusBurn - Guia de Implementação

## 📋 Visão Geral

Esta é uma landing page profissional e otimizada para conversão desenvolvida para promover o produto **CitrusBurn** (suplemento para emagrecimento) através de campanhas de afiliado no Google Ads. A página foi construída do zero com HTML5, CSS3 e JavaScript vanilla, sem dependências externas.

## 🎯 Características Principais

- **Responsivo:** Funciona perfeitamente em desktop, tablet e mobile
- **Otimizado para Conversão:** Design focado em CTA (Call-to-Action) e persuasão
- **Rápido:** Sem frameworks pesados, carregamento ultrarrápido
- **Rastreamento Integrado:** Pronto para Google Analytics e Facebook Pixel
- **SEO-Friendly:** Meta tags, estrutura semântica e performance otimizada
- **Acessível:** Segue padrões WCAG de acessibilidade

## 📁 Estrutura de Arquivos

```
citrusburn-landing/
├── index.html           # Arquivo HTML principal
├── css/
│   └── styles.css       # Estilos CSS (responsivo)
├── js/
│   └── main.js          # JavaScript com rastreamento
├── images/              # Pasta para imagens (vazia, pronta para uso)
└── README.md            # Este arquivo
```

## 🚀 Como Usar

### 1. Fazer Upload para um Servidor

#### Opção A: Hospedagem Compartilhada (cPanel)
1. Conecte-se via FTP ao seu servidor
2. Crie uma pasta (ex: `citrusburn`)
3. Faça upload de todos os arquivos para essa pasta
4. Acesse `seu-dominio.com/citrusburn/`

#### Opção B: Vercel (Recomendado - Gratuito)
1. Acesse [vercel.com](https://vercel.com)
2. Conecte seu repositório Git
3. Clique em "Deploy"
4. Pronto! Sua página estará online em minutos

#### Opção C: Netlify (Gratuito)
1. Acesse [netlify.com](https://netlify.com)
2. Arraste a pasta do projeto
3. Pronto! Sua página estará online

### 2. Configurar Links de Afiliado

Abra o arquivo `js/main.js` e procure pela função `handlePurchase()`:

```javascript
const affiliateLinks = {
    '1-month': 'SEU_LINK_DE_AFILIADO_1_MES',
    '3-month': 'SEU_LINK_DE_AFILIADO_3_MESES',
    '6-month': 'SEU_LINK_DE_AFILIADO_6_MESES'
};
```

Substitua pelos links de afiliado do CitrusBurn que você recebeu.

### 3. Integrar Google Analytics

Descomente o código no final de `js/main.js`:

```javascript
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'SEU_GA_ID');
```

Substitua `SEU_GA_ID` pelo seu ID do Google Analytics.

### 4. Integrar Facebook Pixel

Descomente o código no final de `js/main.js` e substitua `PIXEL_ID` pelo seu ID do Facebook Pixel.

## 📊 Rastreamento de Eventos

A página rastreia automaticamente os seguintes eventos:

| Evento | Descrição |
| :--- | :--- |
| `page_load` | Carregamento da página com source/medium/campaign |
| `section_viewed_*` | Quando o usuário visualiza cada seção |
| `button_clicked` | Quando o usuário clica em um botão CTA |
| `purchase_click` | Quando o usuário clica em "Comprar Agora" |
| `page_exit` | Quando o usuário sai da página (tempo gasto) |

## 🎨 Personalização

### Cores
Edite as variáveis CSS em `css/styles.css`:

```css
:root {
    --primary-color: #FF6B35;      /* Laranja principal */
    --secondary-color: #F7931E;    /* Laranja secundário */
    --accent-color: #004E89;       /* Azul destaque */
    /* ... outras cores */
}
```

### Conteúdo
Edite o arquivo `index.html` para:
- Alterar textos e títulos
- Adicionar/remover seções
- Mudar imagens e ícones
- Ajustar preços e ofertas

### Fontes
A página usa a fonte do sistema `Segoe UI`. Para mudar:

```css
body {
    font-family: 'Sua Fonte Aqui', sans-serif;
}
```

## 📱 Otimizações para Google Ads

### Parâmetros UTM Recomendados

Use estes parâmetros ao criar suas campanhas no Google Ads:

```
https://seu-dominio.com/citrusburn/?utm_source=google&utm_medium=cpc&utm_campaign=citrusburn_feb2026
```

### Configuração de Conversão

1. No Google Ads, crie uma ação de conversão
2. Copie o código de rastreamento
3. Adicione ao `<head>` do `index.html`

## 🔍 SEO - Otimizações

A página inclui:
- ✅ Meta tags descritivas
- ✅ Estrutura H1-H6 semântica
- ✅ URLs amigáveis
- ✅ Imagens com alt text
- ✅ Velocidade otimizada
- ✅ Mobile-first design

## ⚡ Performance

Métricas esperadas:
- **Tempo de carregamento:** < 2 segundos
- **Lighthouse Score:** 90+
- **Core Web Vitals:** Bom

Para melhorar ainda mais:
1. Comprimir imagens com [TinyPNG](https://tinypng.com)
2. Usar CDN para servir arquivos estáticos
3. Ativar cache do navegador no servidor

## 🛡️ Segurança

- Não armazena dados sensíveis no cliente
- Sem dependências externas perigosas
- HTTPS recomendado (essencial para conversão)
- Sem vulnerabilidades conhecidas

## 📞 Suporte e Troubleshooting

### A página não carrega
- Verifique se todos os arquivos foram enviados
- Verifique os caminhos dos arquivos (CSS e JS)
- Limpe o cache do navegador (Ctrl+Shift+Del)

### Os botões não funcionam
- Verifique se os links de afiliado estão corretos
- Abra o console (F12) e procure por erros

### Analytics não rastreia
- Verifique se o ID do Google Analytics está correto
- Aguarde 24 horas para os dados aparecerem

## 💡 Dicas de Conversão

1. **Teste A/B:** Crie 2 versões com cores/textos diferentes
2. **Urgência:** Use "Oferta por tempo limitado"
3. **Prova Social:** Adicione mais depoimentos reais
4. **Garantia:** Destaque a garantia de 30 dias
5. **Mobile:** Teste em celular antes de lançar

## 📈 Próximos Passos

1. ✅ Fazer upload da página
2. ✅ Configurar links de afiliado
3. ✅ Integrar Google Analytics
4. ✅ Criar campanha no Google Ads
5. ✅ Monitorar conversões
6. ✅ Otimizar baseado em dados

## 📄 Licença

Esta landing page foi desenvolvida para fins de marketing de afiliados. Use livremente, mas respeite os direitos do produto CitrusBurn.

---

**Desenvolvido para:** Estratégia de Afiliado em Dólar (Fundo de Funil)  
**Data:** Fevereiro 2026  
**Versão:** 1.0
